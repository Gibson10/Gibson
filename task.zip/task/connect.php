<?php
//link to database

$host = "localhost";
$username = "root";  //Change this later
$password = ""; //Change later
$db_name = "chama_gamma";

$db = mysqli_connect($host, $username,$password,$db_name);