<?php include 'security.php'?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add task</title>
    <link rel="stylesheet" href="boot/css/bootstrap.css"/>

</head>
<body>
<?php include 'nav.php';?>
<div class="container">
    <div class="col-md-4 col-md-offset-4">
        <h3 class="text-center">Add Task</h3>
        <form role="form" action="addtask.php" method="post" placeholder="add new task">

            <div class="form-group">
                <label for="email">task</label>
                <input type="text" class="form-control" name="task" required>
            </div>

            <div class="form-group">
                <label for="email">Date of completion</label>
                <input type="date" class="form-control" name="time" required placeholder="Date of completion">
            </div>

            <button type="submit" class="btn btn-info btn-block">
                Add task</button>
          
        </form>
    </div>
</div>


</body>
</html>
