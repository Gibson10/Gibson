<?php
extract($_POST);
echo "$task $time ";

$db = mysqli_connect("localhost", "root","", "chama_gamma");
$sql = "insert into task (task,time) values ('$task','time')";
mysqli_query($db, $sql) or die (mysqli_error($db));


header("location:task.php");



// <?php  
// $db = mysqli_connect("localhost", "root","", "chama_gamma");
// $sql = "select * from task ";

// $result = mysqli_query($db,$sql) or die (mysqli_error($db));
// $count = mysqli_num_rows($result); 
//  echo $count;

// if($count=$count+1) 

// {
// echo  "New order";
// }

// else if ($count ==$count)
// {
//     echo " no order added yet";
// }
// ?>