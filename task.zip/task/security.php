<?php
 session_start();
 if(!isset($_SESSION['email'])) //Check if email session is not there...if it is not logged in
 {
    header("location:login.php");
 }

?>