<?php
 extract($_GET); 
$db = mysqli_connect("localhost", "root","", "chama_gamma");
$sql = "DELETE  from task where id=$idnum ";
mysqli_query($db, $sql) or die (mysqli_error($db));
echo $idnum; 

header("location:display.php");