
<?php
extract($_GET); 
$db = mysqli_connect("localhost", "root","", "chama_gamma");
$sql ="Update task set status='completed' WHERE $idnum='$idnum'";
mysqli_query($db, $sql) or die (mysqli_error($db));
echo "Completed task";
?>s