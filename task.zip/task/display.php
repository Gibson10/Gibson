<?php include 'security.php'?>

<!doctype html>
<html lang="en">
<head>

    <meta charset="UTF-8">
    <title>Tasks</title>
    <link rel="stylesheet" href="boot/css/bootstrap.css"/>
     <script type="text/javascript" src="http://code.jquery.com/jquery-1.10.1.min.js"></script>
    <style>
        body {background: #5cb85c;}
    </style>

</head>
<body>
 <?php include 'nav.php';?>

<script type="text/javascript">
  var timeout = setTimeout("location.reload(true);",10000);
  function resetTimeout() {
    clearTimeout(timeout);
    timeout = setTimeout("location.reload(true);",10000);
  }
</script>
 

  <div class="container">
      <table class="table" id="example">
          <thead>
            <tr>
               <th>number</th>
                <th>Task</th>
                <th>expected time</th>
                <th>completion time</th>
                
            </tr>
          </thead>
           <tbody>
             <?php
             $db = mysqli_connect("localhost", "root","", "chama_gamma");
             $sql = "select * from task";
             $result = mysqli_query($db, $sql) or die (mysqli_error($db));
             while($row = mysqli_fetch_row($result))
             {

                     $idnum = $row[0];
                     $link1= "manager.php?idnum=$idnum";
                    $idnum = $row[0];
                     $link = "_complete.php?idnum=$idnum";

                 echo "<tr>";
                     echo "<td>$row[0] </td>";
                     echo "<td> $row[1] </td>";
                     echo "<td> $row[2] </td>";
                     echo "<td> $row[3] </td>";
                     echo "<td><a href='$link1'class='btn btn-danger'>Delete</td>";
                     echo "<td><a href='$link' class='btn btn-danger'> Complete</td>";
                 echo "</tr>";
             }
             ?>
           </tbody>
      </table>
  </div>


 <link rel="stylesheet" href="boot/css/dataTables.css"/>
 <script src="boot/js/jquery.min.js"></script>
 <script src="boot/js/dataTables.js"></script>
 <script>
     $("#example").DataTable();
 </script>

<?php
  echo $_SESSION['count'];

?>

</body>
</html>