<?php
 session_start();
 if( !isset($_SESSION['email'])) //Check if email session is not there...if it is not logged in
 {
    header("location:login.php");
 }

<?
extract($_GET); 
$db = mysqli_connect("localhost", "root","", "chama_gamma");

mysqli_query($db, $sql) or die (mysqli_error($db));
?>