
<?php

$db = mysqli_connect("localhost", "root","", "chama_gamma");

$sql = "select * from task ";

$result = mysqli_query($db,$sql) or die (mysqli_error($db));
$count = mysqli_num_rows($result); 



    if(!isset($_SESSION)) 
    { 
       session_start(); //Create the file

$_SESSION['count'] = $count;
 echo $_SESSION['count'];
}

?>