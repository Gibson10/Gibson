<?php
extract($_POST);
//echo "$names $email $password";

include 'connect.php';
$sql = "insert into users values (null,'$names','$email','$password')";
mysqli_query($db, $sql) or die (mysqli_error($db));

header("location:login.php");