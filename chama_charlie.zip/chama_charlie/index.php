<?php include 'security.php'?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Home</title>
    <link rel="stylesheet" href="boot/css/bootstrap.css"/>
    <style>
        body {background: #5cb85c;}
    </style>
</head>
<body>
 <?php include 'nav.php';?>

 <div class="container">
     <div class="col-md-4 col-md-offset-4">
         <h3 class="text-center">Register</h3>
         <form role="form" action="register.php" method="post">

             <div class="form-group">
                 <label for="email">Names</label>
                 <input type="text" class="form-control" name="names" required>
             </div>

             <div class="form-group">
                 <label for="email">Id number</label>
                 <input type="text" class="form-control" name="idnum" required>
             </div>

             <div class="form-group">
                 <label for="email">Phone number</label>
                 <input type="text" class="form-control" name="phone" required>
             </div>

             <button type="submit" class="btn btn-info btn-block">
                 Submit</button>
         </form>

     </div>
 </div>

</body>
</html>