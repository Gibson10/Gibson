<?php include 'security.php'?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Members</title>
    <link rel="stylesheet" href="boot/css/bootstrap.css"/>
    <style>
        body {background: #5cb85c;}
    </style>
</head>
<body>
 <?php include 'nav.php';?>
  <div class="container">
      <table class="table" id="example">
          <thead>
            <tr>
                <th>ID</th>
                <th>NAMES</th>
                <th>PHONE</th>
                <th>NATIONAL ID</th>
            </tr>
          </thead>
           <tbody>
             <?php
             $db = mysqli_connect("localhost", "root","", "chama_gamma");
             $sql = "select * from members";
             $result = mysqli_query($db, $sql) or die (mysqli_error($db));
             while($row = mysqli_fetch_row($result))
             {
                 echo "<tr>";
                     echo "<td>$row[0] </td>";
                     echo "<td> $row[1] </td>";
                     echo "<td> $row[3] </td>";
                     echo "<td> $row[2] </td>";
                 echo "</tr>";
             }
             ?>
           </tbody>
      </table>
  </div>


 <link rel="stylesheet" href="boot/css/dataTables.css"/>
 <script src="boot/js/jquery.min.js"></script>
 <script src="boot/js/dataTables.js"></script>
 <script>
     $("#example").DataTable();
 </script>
</body>
</html>