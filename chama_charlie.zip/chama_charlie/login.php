<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <link rel="stylesheet" href="boot/css/bootstrap.css"/>

</head>
<body>

<div class="container">
    <div class="col-md-4 col-md-offset-4">
        <h3 class="text-center">Login</h3>
        <form role="form" action="process_login.php" method="post">

            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" class="form-control" name="email" required>
            </div>

            <div class="form-group">
                <label for="email">Password</label>
                <input type="password" class="form-control" name="password" required>
            </div>

            <button type="submit" class="btn btn-info btn-block">
                Login</button>
            Not a member...<a href="signup.php">Register here</a>
        </form>
    </div>
</div>


</body>
</html>
