<?php
//process loans
extract($_POST);

include 'connect.php';
$sql = "select * from members where idnum = '$idnum'"; //Check if record exists
$result = mysqli_query($db, $sql) or die (mysqli_error($db));
$count = mysqli_num_rows($result); //If 1 then user exists...if 0 user doesn't exist

$sql2 = "select * from loans where member_id ='$idnum' and status='pending'"; //Check if you have a pending loan
$result2 = mysqli_query($db, $sql2) or die (mysqli_error($db));
$count2 = mysqli_num_rows($result2);

if($count == 1 and $count2== 0)
{
    //success
    $sql3="insert into loans (member_id,amount) values('$idnum', $amount)";
    mysqli_query($db, $sql3) or die (mysqli_error($db));

    echo "Your loan of Ksh$amount has been processed successfully";
}
else
{
    echo "You have a pending loan or member doesn't exist ";
}