<?php
// extract($_POST);
//echo "$names $idnum $phone";

include 'connect.php';
$sql = "insert into members values(null, '$names','$idnum','$phone')";
mysqli_query($db, $sql) or die (mysqli_error($db));

header("location:task.php");