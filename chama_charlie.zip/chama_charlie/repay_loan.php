<?php

extract($_POST);
include 'connect.php';

$sql_a = "select amount from loans where member_id=$idnum and status='pending'";
$result_a = mysqli_query($db,$sql_a);
$row_a = mysqli_fetch_row($result_a);
$loan_amount = $row_a[0];

if( !$loan_amount > 0) //not greater than
{
    echo "You don't have any loan";
    exit;
}

$idnum = mysqli_real_escape_string($db, $idnum); //Prevent sql injection.
$amount = mysqli_real_escape_string($db, $amount);
$sql = "insert into repayments(natid,amount) values('$idnum',$amount)";
//echo $sql;
mysqli_query($db, $sql);

$sql_b = "select sum(amount) from repayments where natid='$idnum'";
$result_b = mysqli_query($db,$sql_b);
$row_b = mysqli_fetch_row($result_b);
$total_repayments = $row_b[0];

echo "Loan is $loan_amount<br>";
echo "Amount paid is $total_repayments<br>";

if($total_repayments >= $loan_amount)
{
    //loan cleared
    $sql ="update loans set status='cleared' where member_id='$idnum'";
    mysqli_query($db,$sql);
    echo "Your loan has been repaid fully";
}
