<?php
//Authenticate login

extract($_POST);
include 'connect.php';
$sql = "select * from users where email='$email' and password='$password'";

$result = mysqli_query($db,$sql) or die (mysqli_error($db));
$count = mysqli_num_rows($result); //If 1 then user exists...if 0 user doesn't exist

if($count == 1)
{
    //success
    $row = mysqli_fetch_row($result);
    $name = $row[1];
    session_start(); //Create the file
    $_SESSION['names'] = $name;
    $_SESSION['email'] = $email;
    header("location:index.php");
}
else
{
    echo "Wrong email or password";
}


