<?php include 'security.php'?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Balances</title>
    <link rel="stylesheet" href="boot/css/bootstrap.css"/>
    <style>
        body {background: #5cb85c;}
    </style>
</head>
<body>
 <?php include 'nav.php';?>
 <div class="container">
     <table class="table" id="example">
         <thead>
         <tr>
             <th>ID NUMBER</th>
             <th>NAMES</th>
             <th>AMOUNT</th>
             <th>BORROW DATE</th>
             <th>STATUS</th>
             <th>REPAY</th>
         </tr>
         </thead>
         <tbody>
         <?php
         $db = mysqli_connect("localhost", "root","", "chama_gamma");
         $sql = "SELECT members.natid,members.name,loans.amount,loans.borrow_date,loans.status from members JOIN loans on members.natid=loans.member_id where loans.status='pending'";
         $result = mysqli_query($db, $sql) or die (mysqli_error($db));
         while($row = mysqli_fetch_row($result))
         {
             $idnum = $row[0];
             $link = "repay.php?idnum=$idnum";

             echo "<tr>";
             echo "<td> $row[0] </td>";
             echo "<td> $row[1] </td>";
             echo "<td> $row[2] </td>";
             echo "<td> $row[3] </td>";
             echo "<td> $row[4] </td>";
             echo "<td> <a href='$link' class='btn btn-info'>Repay</a> </td>";
             echo "</tr>";
         }
         ?>
         </tbody>
     </table>
 </div>

 <link rel="stylesheet" href="boot/css/dataTables.css"/>
 <script src="boot/js/jquery.min.js"></script>
 <script src="boot/js/dataTables.js"></script>
 <script>
     $("#example").DataTable();
 </script>
</body>
</html>