<?php
extract($_POST);


 $db = mysqli_connect("localhost", "root","", "irene");
$sql = "insert into share values (null,'$name','$email','$number','$message')";
mysqli_query($db, $sql) or die (mysqli_error($db));

header("location:share.html");