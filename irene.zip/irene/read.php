
<?php
$db =mysqli_connect("localhost", "root", "","irene");
 $sql="select * from share";
  $result = mysqli_query($db,$sql);
  while($row = mysqli_fetch_row($result))

  {

	echo "<hr>$row[0]</hr>";	
    echo "<hr>$row[1]</hr>";
    echo "<hr>$row[2]</hr>";
    echo "<hr>$row[3]</hr>";
    echo "<hr class='font:bold'>$row[4]</hr>";
}
?>
