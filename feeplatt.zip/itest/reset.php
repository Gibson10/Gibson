<html>
<head>
<title>insert.html</title>
<meta charset="UTF_8">
<meta lang="en">

 <link rel="stylesheet" href="css/style.css">
  
</head>
<body>
<fieldset>
<form action="reset2.php"method="POST">
   
<h1 class="sign-up-title">CHANGE YOUR PASSWORD</h1>
<input type='hidden' name='submitted' id='submitted' value='1'/> 
<div class='container'><span id='login_username_errorloc' class='error'></span></div>
<input type="text"class="sign-up-input"name="name"placeholder="enter your  name"maxlength="50"autofocus><br>
<input type="password"class="sign-up-input"name="password"id="password"placeholder="enter new password"maxlength="50"><br>
<span id='login_password_errorloc' class='error'></span>
<input type="submit"value="sign up"class="sign-up-button">
</fieldset>
</form>
</body>
</html>