<!DOCTYPE html>
<html>
<head>
<title>insert.html</title>
<meta charset="UTF_8">
<meta lang="en">

 <link rel="stylesheet" href="css/style.css">
  
</head>
<body>
<?php
$name=$_POST['name'];
$password=$_POST['password'];
$conn=mysql_connect("localhost","root","");
$sql="UPDATE testdb.neville SET password=$password WHERE name='$name';";
mysql_query($sql,$conn);

?>
</body>
</html>