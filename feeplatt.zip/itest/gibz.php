<?php
require_once("./include/membersite_config.php");

if(!$fgmembersite->CheckLogin())
{
    $fgmembersite->RedirectToURL("login.php");
    exit;
	
}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US">
<head>
<title>MobiPay</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<link href='http://fonts.googleapis.com/css?family=Lato:100,300,400,700,900' rel='stylesheet' type='text/css'>
<link href="css/style_2.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/owl.carousel.css" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="css/magnific-popup.css">
<script type="text/javascript" src="js/jquery.min.js"></script>
<script src="js/owl.carousel.js"></script>
	<script>
			$(document).ready(function() {
				$("#owl-demo").owlCarousel({
					items : 4,
					lazyLoad : true,
					autoPlay : true,
					navigation : true,
					navigationText : ["", ""],
					rewindNav : false,
					scrollPerPage : false,
					pagination : false,
					paginationNumbers : false,
				});
			});
		</script>
		<!-- //Owl Carousel Assets -->
		<!-----768px-menu----->
		<link type="text/css" rel="stylesheet" href="css/jquery.mmenu.all.css" />
		<script type="text/javascript" src="js/jquery.mmenu.js"></script>
			<script type="text/javascript">
				//	The menu on the left
				$(function() {
					$('nav#menu-left').mmenu();
				});
		</script>
		<!-----//768px-menu----->
 <meta http-equiv='Content-Type' content='text/html; charset=utf-8'/>
      <title>Home page</title>
      <link rel="STYLESHEET" type="text/css" href="style/fg_membersite.css">
</head>
<body>
<!-- start header -->
<div class="header_bg">
<div class="wrap">
	<div class="header">
		<div class="logo">
			<a href="index.html">
				<img src="images/platt.jpg" alt=""/>
				<div class="clear">FEEPLATT</div>
			 </a>
		</div>
		<div class="text">
		  <p>Kenya's Favourite E-commerce Site</p>
		
Welcome back <?= $fgmembersite->UserFullName(); ?>!

<p><a href='change-pwd.php'>Change password</a></p>
<p><a href='logout.php'>Logout</a></p>
		</div>
		<div class="clear"> </div>
	</div>
</div>
</div>
<!-- start header -->
<div class="header_btm">
	<div class="wrap">
		<!------start-768px-menu---->
			<div id="page">
					<div id="header">
						<a class="navicon" href="#menu-left"> </a>
					</div>
					<nav id="menu-left">
						<ul>
							<li class="active"><a href="index.php">Home</a></li>
							<li><a href="contact.html">Contact us</a></li>
<li><a href="about.html">About Us</a></li>
<li><a href="pages.html"></a><Communications/li>
<li><a href="blog.html">Blog</a></li>
						</ul>
					</nav>
			</div>
		<!------start-768px-menu---->
			<div class="header_sub">
				<div class="h_menu">
					<ul>
						<li class="active"><a href="index.php">Home</a></li>
<li><a href="about.html">About Us</a></li>
<li><a href="pages.html">Communications</a></li>
<li><a href="blog.html">Transactions</a></li>

						<li><a href="contact.html">Contact us</a></li>
					</ul>
				</div>
				<div class="h_search">
		    		<form>
		    			<input type="text" value="" placeholder="search something...">
		    			<input type="submit" value="">
		    		</form>
				</div>
				<div class="clear"> </div>
			</div>
	</div>
</div>
	<!---start-banner---->
			<div class="banner" id="move-top">
				<!----start-image-slider---->
					<div data-scroll-reveal="enter bottom but wait 0.7s" class="img-slider" id="home">
						<div class="wrap">
							<div class="slider">
								<ul id="jquery-demo">
								  <li>
								    <a href="#slide1">
								    </a>
								    <div data-scroll-reveal="enter bottom but wait 0.7s" class="slider-detils">
								    	<h3>Pay Fees From The Comfort Of Your Home</h3>
								    	<span></span>
								    </div>
								  </li>
								  <li>
								    <a href="#slide2">
								    </a>
								      <div data-scroll-reveal="enter bottom but wait 1s" class="slider-detils">
								    	<h3>Safest Online Money Manager</h3>
								    	<span>Mobipay Uses the Latest SSL Technology For Your Security </span>
								    	</div>
								  </li>
								  <li>
								    <a href="#slide3">
								    </a>
								      <div data-scroll-reveal="enter bottom but wait 1.5s" class="slider-detils">
								      	<h3>Our Helplines Are Always Open</h3>
								    	<span>24 hour service</span>
								    </div>
								  </li>
								</ul>
							</div>
						</div>
					</div>
					<div class="clear"> </div>
				</div>
						<!---slider---->
				<link rel="stylesheet" href="css/slippry.css">
				<script src="js/jquery-ui.js" type="text/javascript"></script>
				<script src="js/scripts-f0e4e0c2.js" type="text/javascript"></script>
				<script>
					  jQuery('#jquery-demo').slippry({
					  // general elements & wrapper
					  slippryWrapper: '<div class="sy-box jquery-demo" />', // wrapper to wrap everything, including pager
					  // options
					  adaptiveHeight: false, // height of the sliders adapts to current slide
					  useCSS: false, // true, false -> fallback to js if no browser support
					  autoHover: false,
					  transition: 'fade'
					});
				</script>
				<!---scrooling-script--->
					<!----//End-image-slider---->
					<div class="simple-text">
						<div class="wrap">
							<h4><a href="signup.php" style="font-color:#ff00ff !important;">Sign Up Now For Free</a></h4>
							<p>To Use Mobidata all what you need is an account and a credit card.</p>
						</div>
					</div>
			<div class="Recent-wroks"><!-- start services -->
				<div class="wrap">
				<div class="Recent-wrok">
					<h5 class="heading">Our Services</h5>
					<!----start-img-cursual---->
					<div id="owl-demo" class="owl-carousel">
						<div class="item">
							<div class="cau_left">
								<div id="nivo-lightbox-demo"> <p> <a href="img/index.jpg" data-lightbox-gallery="gallery1" id="nivo-lightbox-demo"> <span class="rollover"> </span></a> </p></div>
								<img src="img/index.jpg" >
							</div>
							<div class="cau_left">
								<h4><a href="#">Conveniency.</a></h4>
								<p>
Pay Fees From Your Home or Even On The Go With The MobiPay App. 

								</p>
							</div>
						</div>
						<div class="item">
							<div class="cau_left">
								<div id="nivo-lightbox-demo"> <p> <a href="img/index4.jpg" data-lightbox-gallery="gallery1" id="nivo-lightbox-demo"> <span class="rollover"> </span></a> </p></div>
								<img src="img/index4.jpg" >
							</div>
							<div class="cau_left">
								<h4><a href="#">Security.</a></h4>
								<p>
MobiPay Uses the Latest SSL Security Technologies to Encrypt Your Transaction.
														</p>
							</div>
						</div>
						<div class="item">
							<div class="cau_left">
								<div id="nivo-lightbox-demo"> <p> <a href="img/images12.jpg" data-lightbox-gallery="gallery1" id="nivo-lightbox-demo"> <span class="rollover"> </span></a> </p></div>
								<img src="img/images12.jpg" >
							</div>
							<div class="cau_left">
								<h4><a href="#"></a></h4>
								<p>
									Keep Track of All Your Payments In One Page!
								</p>
							</div>
						</div>
						<div class="item">
							<div class="cau_left">
								<div id="nivo-lightbox-demo"> <p> <a href="img/images9.jpg" data-lightbox-gallery="gallery1" id="nivo-lightbox-demo"> <span class="rollover"> </span></a> </p></div>
								<img src="img/images9.jpg" >
							</div>
							<div class="cau_left">
								<h4><a href="#">updates</a></h4>
								<p>
									Receive Updates Directly From the School.
								</p>
							</div>
						</div>
						<div class="item">
							<div class="cau_left">
								<div id="nivo-lightbox-demo"> <p> <a href="img/images34.jpg" data-lightbox-gallery="gallery1" id="nivo-lightbox-demo"> <span class="rollover"> </span></a> </p></div>
								<img src="img/images34.jpg" >
							</div>
							<div class="cau_left">
								<h4><a href="#">speed of payment</a></h4>
								<p>
								Fees is paid by only the press of a button	
								</p>
							</div>
						</div>
						<div class="item">
							<div class="cau_left">
								<div id="nivo-lightbox-demo"> <p> <a href="img/index3.jpg" data-lightbox-gallery="gallery1" id="nivo-lightbox-demo"> <span class="rollover"> </span></a> </p></div>
								<img src="img/index3.jpg" >
							</div>
							<div class="cau_left">
								<h4><a href="#"></a></h4>
								<p>
								You can pay upfront
								</p>
							</div>
						</div>
						<div class="item">
							<div class="cau_left">
								<div id="nivo-lightbox-demo"> <p> <a href="img/images8.jpg" data-lightbox-gallery="gallery1" id="nivo-lightbox-demo"> <span class="rollover"> </span></a> </p></div>
								<img src="img/images8.jpg" >
							</div>
							<div class="cau_left">
								<h4><a href="#"></a></h4>
								<p>
									You canpay small amounts before the months ends and the school can also allow you to pay at vspecific intervals.
								</p>
							</div>
						</div>
						<div class="item">
							<div class="cau_left">
								<div id="nivo-lightbox-demo"> <p> <a href="img23/.jpg" data-lightbox-gallery="gallery1" id="nivo-lightbox-demo"> <span class="rollover"> </span></a> </p></div>
								<img src="img/images23.jpg" >
							</div>
							<div class="cau_left">
								<h4><a href="#"></a></h4>
								<p>
									You don't have to travel to pay school fees anymore!!!!!!!Mobifee caters for all that.
								</p>
							</div>
						</div>
						<div class="item">
							<div class="cau_left">
								<div id="nivo-lightbox-demo"> <p> <a href="img/image1.jpg" data-lightbox-gallery="gallery1" id="nivo-lightbox-demo"> <span class="rollover"> </span></a> </p></div>
								<img src="img/images1.jpg" >
							</div>
							<div class="cau_left">
								<h4><a href="#"></a></h4>
								<p>
									
								</p>
							</div>
						</div>
						<div class="item">
							<div class="cau_left">
								<div id="nivo-lightbox-demo"> <p> <a href="img/index.jpg" data-lightbox-gallery="gallery1" id="nivo-lightbox-demo"> <span class="rollover"> </span></a> </p></div>
								<img src="img/index.jpg" >
							</div>
							<div class="cau_left">
								<h4><a href="#">MobiPays</a></h4>
								<p>
									
								</p>
							</div>
						</div>
						<div class="item">
							<div class="cau_left">
								<div id="nivo-lightbox-demo"> <p> <a href="img/index4.jpg" data-lightbox-gallery="gallery1" id="nivo-lightbox-demo"> <span class="rollover"> </span></a> </p></div>
								<img src="img/index4.jpg" >
							</div>
							<div class="cau_left">
								<h4><a href="#">Eficient</a></h4>
								<p>
									Our services are offered for 24hrs online
								</p>
							</div>
						</div>
						<div class="item">
							<div class="cau_left">
								<div id="nivo-lightbox-demo"> <p> <a href="img/images12.jpg" data-lightbox-gallery="gallery1" id="nivo-lightbox-demo"> <span class="rollover"> </span></a> </p></div>
								<img  src="img/images12.jpg">
							</div>
							<div class="cau_left">
								<h4><a href="#"></a></h4>
								<p>
								You can trust us with your child's future	
								</p>
							</div>
						</div>
					</div>
					<!----//End-img-cursual---->
				</div>
				 <script type="text/javascript" src="js/nivo-lightbox.min.js"></script>
				<script type="text/javascript">
				$(document).ready(function(){
				    $('#nivo-lightbox-demo a').nivoLightbox({ effect: 'fade' });
				});
				</script>

				</div>
			</div>
			<div class="last_posts"><!-- start last_posts -->
				<div class="wrap">
					<h5 class="heading">Last posts</h5>
					<div class="l-grids">
						<div class="l-grid-1">
							<div class="desc">
								<h3>You will be suprised how fast you can pay</h3>
								<span>2nd  &nbsp; sep</span>
								<p>.</p>
							</div>
							<img src="images/im1.jpg">	
							<div class="clear"> </div>
						</div>
						<div class="l-grid-1 l-grid-2">
							<div class="desc">
								<h3>By a touch of your fingers you do great things</h3>
								<span>2nd  &nbsp; sep</span>
								<p></p>
							</div>
							<img src="images/im.jpg">	
							<div class="clear"> </div>
						</div>
						<div class="clear"> </div>
					</div>
				</div>
			</div>
			<div class="testimonial"><!-- start last_posts -->
				<div class="wrap">
					<h5 class="heading">testimonials</h5>
					<div class="test-grids">
						<div class="test-desc">
							<h3>your testimonial here</h3>
							<p>Through mobipay you not onli get to pay for your childs fee but also get updates from their school on fee balance.You don't have to involve your son in the payment process. </p>
							 <p>U.</p>
						</div>
						<div class="img_1">
							<img src="images/avator.png">
						</div>
						<div class="clear"> </div>
					</div>
				</div>
			</div>
			<div class="get_in_touch"><!-- start last_posts -->
				<div class="wrap">
					<h5 class="heading">get in touch</h5>
					<div class="get-left">
						<p>You can easily get in touch with us by email and ask any questions on any subject be sure of a fast answer .</p>
						<p>You can also contact us on our facebook page or folllow us on twitter</p>
					</div>
					<div class="get-right">
						<form action="messages.php"method="POST">
								<ul>
									<li class="name">
										<a href="#" class="icon user"> </a>
										<input type="text" placeholder="Your name" required=""name="name">>
										<div class="clear"> </div>
									</li> 
									<li class="email_1">
										<a href="#" class="icon mail"> </a>
										<input type="email" placeholder="yourname@email.com" required=""name="email">
										<div class="clear"> </div>
									</li> 
										<div class="clear"> </div>
										<li>
										<textarea class="plain buffer" name="message" placeholder="Your text here"> Your text here</textarea>
										</li>
										<input type="submit"  value="Send" />
						
								</ul>
						</form>
				</div>
				<div class="clear"> </div>
					</div>
			</div>
			<div class="footer">
				<div class="wrap">
					<div class="footer-left">
						<h3>About Mobipay</h3>
						<p>Mobipay was designed to help parents to pay fees online without necessarily going to the bank.This helps to reduce problems associated with the bank payment method.</p>
						<p>It also enables direct communication between the school and the parents without involving the students</p>
					<div class="detail">
						<ul>
							<li><a href="#">home/</a></li>
							<li><a href="#">term of services/</a></li>
							<li><a href="#">license/</a></li>
							<li><a href="#">pess</a></li>
							<div class="clear"> </div>	
						</ul>
					</div>
					<div class="soc_icons soc_icons1">
							<ul>
								<li><a class="icon1" href="#"> </a> </li>
								<li><a class="icon2" href="#"> </a></li>
								<li><a class="icon3" href="#"> </a></li>
								<div class="clear"> </div>	
							</ul>
								
					</div>
					</div>
					<div class="footer-right">
						<h3>twitter</h3>
						<div class="comments1">
							<p>I just cant imagine i don't have to go to school every time i want to pay fees.It feels so good being able to pay for my son just sitted at my house.</p>
							<span>~12 hours ago</span>
						</div>
						<div class="comments1">
							<p>.</p>
							<span>~2 days ago</span>
						</div>
					</div>
					<div class="clear"> </div>	
				</div>
			</div>
			<div class="copy">
				      
			  </div>
</body>
</html>
