<?Php
include "include/session.php";
include "config.php";
?>
<?Php
require "check.php";
require "bottom.php";
?>
<!doctype html>
<html>
<head>
<title>MobiPay</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<link href='http://fonts.googleapis.com/css?family=Lato:100,300,400,700,900' rel='stylesheet' type='text/css'>
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/owl.carousel.css" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="css/magnific-popup.css">
<script type="text/javascript" src="js/jquery.min.js"></script>
<script src="js/owl.carousel.js"></script>
	<script>
			$(document).ready(function() {
				$("#owl-demo").owlCarousel({
					items : 4,
					lazyLoad : true,
					autoPlay : true,
					navigation : true,
					navigationText : ["", ""],
					rewindNav : false,
					scrollPerPage : false,
					pagination : false,
					paginationNumbers : false,
				});
			});
		</script>
		<!-- //Owl Carousel Assets -->
		<!-----768px-menu----->
		<link type="text/css" rel="stylesheet" href="css/jquery.mmenu.all.css" />
		<script type="text/javascript" src="js/jquery.mmenu.js"></script>
			<script type="text/javascript">
				//	The menu on the left
				$(function() {
					$('nav#menu-left').mmenu();
				});
		</script>
		<!-----//768px-menu----->
<title>Die slow</title>
</head>
<body>
<!---start-banner---->
			<div class="banner" id="move-top">
				<!----start-image-slider---->
					<div data-scroll-reveal="enter bottom but wait 0.7s" class="img-slider" id="home">
						<div class="wrap">
							<div class="slider">
								<ul id="jquery-demo">
								  <li>
								    <a href="#slide1">
								    </a>
								    <div data-scroll-reveal="enter bottom but wait 0.7s" class="slider-detils">
								    	<h3>Pay Fees From The Comfort Of Your Home</h3>
								    	<span></span>
								    </div>
								  </li>
								  <li>
								    <a href="#slide2">
								    </a>
								      <div data-scroll-reveal="enter bottom but wait 1s" class="slider-detils">
								    	<h3>Safest Online Money Manager</h3>
								    	<span>Mobipay Uses the Latest SSL Technology For Your Security </span>
								    	</div>
								  </li>
								  <li>
								    <a href="#slide3">
								    </a>
								      <div data-scroll-reveal="enter bottom but wait 1.5s" class="slider-detils">
								      	<h3>Our Helplines Are Always Open</h3>
								    	<span>24 hour service</span>
								    </div>
								  </li>
								</ul>
							</div>
						</div>
					</div>
					<div class="clear"> </div>
				</div>
						<!---slider---->
				<link rel="stylesheet" href="css/slippry.css">
				<script src="js/jquery-ui.js" type="text/javascript"></script>
				<script src="js/scripts-f0e4e0c2.js" type="text/javascript"></script>
				<script>
					  jQuery('#jquery-demo').slippry({
					  // general elements & wrapper
					  slippryWrapper: '<div class="sy-box jquery-demo" />', // wrapper to wrap everything, including pager
					  // options
					  adaptiveHeight: false, // height of the sliders adapts to current slide
					  useCSS: false, // true, false -> fallback to js if no browser support
					  autoHover: false,
					  transition: 'fade'
					});
				</script>
				<!---scrooling-script--->
					<!----//End-image-slider---->
					<div class="simple-text">
						<div class="wrap">
							<h4><a href="signup.php" style="font-color:#ff00ff !important;">Sign Up Now For Free</a></h4>
							<p>To Use Mobidata all what you need is an account and a credit card.</p>
						</div>
					</div>
			<div class="Recent-wroks"><!-- start services -->
				<div class="wrap">
				<div class="Recent-wrok">
					<h5 class="heading">Our Services</h5>
					<!----start-img-cursual---->
					<div id="owl-demo" class="owl-carousel">
						<div class="item">
							<div class="cau_left">
								<div id="nivo-lightbox-demo"> <p> <a href="images/11.jpg" data-lightbox-gallery="gallery1" id="nivo-lightbox-demo"> <span class="rollover"> </span></a> </p></div>
								<img src="images/1.jpg" >
							</div>
							<div class="cau_left">
								<h4><a href="#">Conveniency.</a></h4>
								<p>
Pay Fees From Your Home or Even On The Go With The MobiPay App. 

								</p>
							</div>
						</div>
						<div class="item">
							<div class="cau_left">
								<div id="nivo-lightbox-demo"> <p> <a href="images/22.jpg" data-lightbox-gallery="gallery1" id="nivo-lightbox-demo"> <span class="rollover"> </span></a> </p></div>
								<img src="images/2.jpg" >
							</div>
							<div class="cau_left">
								<h4><a href="#">Security.</a></h4>
								<p>
MobiPay Uses the Latest SSL Security Technologies to Encrypt Your Transaction.
														</p>
							</div>
						</div>
						<div class="item">
							<div class="cau_left">
								<div id="nivo-lightbox-demo"> <p> <a href="images/33.jpg" data-lightbox-gallery="gallery1" id="nivo-lightbox-demo"> <span class="rollover"> </span></a> </p></div>
								<img src="images/3.jpg" >
							</div>
							<div class="cau_left">
								<h4><a href="#"></a></h4>
								<p>
									Keep Track of All Your Payments In One Page!
								</p>
							</div>
						</div>
						<div class="item">
							<div class="cau_left">
								<div id="nivo-lightbox-demo"> <p> <a href="images/44.jpg" data-lightbox-gallery="gallery1" id="nivo-lightbox-demo"> <span class="rollover"> </span></a> </p></div>
								<img src="images/4.jpg" >
							</div>
							<div class="cau_left">
								<h4><a href="#">updates</a></h4>
								<p>
									Receive Updates Directly From the School.
								</p>
							</div>
						</div>
						<div class="item">
							<div class="cau_left">
								<div id="nivo-lightbox-demo"> <p> <a href="images/11.jpg" data-lightbox-gallery="gallery1" id="nivo-lightbox-demo"> <span class="rollover"> </span></a> </p></div>
								<img src="images/1.jpg" >
							</div>
							<div class="cau_left">
								<h4><a href="#">speed of payment</a></h4>
								<p>
								Fees is paid by only the press of a button	
								</p>
							</div>
						</div>
						<div class="item">
							<div class="cau_left">
								<div id="nivo-lightbox-demo"> <p> <a href="images/22.jpg" data-lightbox-gallery="gallery1" id="nivo-lightbox-demo"> <span class="rollover"> </span></a> </p></div>
								<img src="images/2.jpg" >
							</div>
							<div class="cau_left">
								<h4><a href="#"></a></h4>
								<p>
								You can pay upfront
								</p>
							</div>
						</div>
						<div class="item">
							<div class="cau_left">
								<div id="nivo-lightbox-demo"> <p> <a href="images/44.jpg" data-lightbox-gallery="gallery1" id="nivo-lightbox-demo"> <span class="rollover"> </span></a> </p></div>
								<img src="images/4.jpg" >
							</div>
							<div class="cau_left">
								<h4><a href="#">Lorem ipsum</a></h4>
								<p>
									You canpay small amounts before the months ends and the school can also allow you to pay at vspecific intervals.
								</p>
							</div>
						</div>
						<div class="item">
							<div class="cau_left">
								<div id="nivo-lightbox-demo"> <p> <a href="images/33.jpg" data-lightbox-gallery="gallery1" id="nivo-lightbox-demo"> <span class="rollover"> </span></a> </p></div>
								<img src="images/3.jpg" >
							</div>
							<div class="cau_left">
								<h4><a href="#"></a></h4>
								<p>
									You don't have to travel to pay school fees anymore!!!!!!!Mobifee caters for all that.
								</p>
							</div>
						</div>
						<div class="item">
							<div class="cau_left">
								<div id="nivo-lightbox-demo"> <p> <a href="images/11.jpg" data-lightbox-gallery="gallery1" id="nivo-lightbox-demo"> <span class="rollover"> </span></a> </p></div>
								<img src="images/1.jpg" >
							</div>
							<div class="cau_left">
								<h4><a href="#"></a></h4>
								<p>
									
								</p>
							</div>
						</div>
						<div class="item">
							<div class="cau_left">
								<div id="nivo-lightbox-demo"> <p> <a href="images/44.jpg" data-lightbox-gallery="gallery1" id="nivo-lightbox-demo"> <span class="rollover"> </span></a> </p></div>
								<img src="images/4.jpg" >
							</div>
							<div class="cau_left">
								<h4><a href="#">MobiPays</a></h4>
								<p>
									
								</p>
							</div>
						</div>
						<div class="item">
							<div class="cau_left">
								<div id="nivo-lightbox-demo"> <p> <a href="images/33.jpg" data-lightbox-gallery="gallery1" id="nivo-lightbox-demo"> <span class="rollover"> </span></a> </p></div>
								<img src="images/3.jpg" >
							</div>
							<div class="cau_left">
								<h4><a href="#">Eficient</a></h4>
								<p>
									Our services are offered for 24hrs online
								</p>
							</div>
						</div>
						<div class="item">
							<div class="cau_left">
								<div id="nivo-lightbox-demo"> <p> <a href="images/22.jpg" data-lightbox-gallery="gallery1" id="nivo-lightbox-demo"> <span class="rollover"> </span></a> </p></div>
								<img  src="images/2.jpg">
							</div>
							<div class="cau_left">
								<h4><a href="#"></a></h4>
								<p>
									
								</p>
							</div>
						</div>
					</div>
					<!----//End-img-cursual---->
				</div>
				 <script type="text/javascript" src="js/nivo-lightbox.min.js"></script>
				<script type="text/javascript">
				$(document).ready(function(){
				    $('#nivo-lightbox-demo a').nivoLightbox({ effect: 'fade' });
				});
				</script>

				</div>
			</div>
			<div class="last_posts"><!-- start last_posts -->
				<div class="wrap">
					<h5 class="heading">Last posts</h5>
					<div class="l-grids">
						<div class="l-grid-1">
							<div class="desc">
								<h3>You will be suprised how fast you can pay</h3>
								<span>2nd  &nbsp; sep</span>
								<p>.</p>
							</div>
							<img src="images/im1.jpg">	
							<div class="clear"> </div>
						</div>
						<div class="l-grid-1 l-grid-2">
							<div class="desc">
								<h3>By a touch of your fingers you do great things</h3>
								<span>2nd  &nbsp; sep</span>
								<p></p>
							</div>
							<img src="images/im.jpg">	
							<div class="clear"> </div>
						</div>
						<div class="clear"> </div>
					</div>
				</div>
			</div>
			<div class="testimonial"><!-- start last_posts -->
				<div class="wrap">
					<h5 class="heading">testimonials</h5>
					<div class="test-grids">
						<div class="test-desc">
							<h3>your testimonial here</h3>
							<p>Through mobipay you not onli get to pay for your childs fee but also get updates from their school on fee balance.You don't have to involve your son in the payment process. </p>
							 <p>U.</p>
						</div>
						<div class="img_1">
							<img src="images/avator.png">
						</div>
						<div class="clear"> </div>
					</div>
				</div>
			</div>
			<div class="get_in_touch"><!-- start last_posts -->
				<div class="wrap">
					<h5 class="heading">get in touch</h5>
					<div class="get-left">
						<p>You can easily get in touch with us by email and ask any questions on any subject be sure of a fast answer .</p>
						<p>You can also contact us on our facebook page or folllow us on twitter</p>
					</div>
					<div class="get-right">
						<form>
								<ul>
									<li class="name">
										<a href="#" class="icon user"> </a>
										<input type="text" placeholder="Your name"name="name" required="">
										<div class="clear"> </div>
									</li> 
									<li class="email_1">
										<a href="#" class="icon mail"> </a>
										<input type="email" placeholder="yourname@email.com" name="email" required="">
										<div class="clear"> </div>
									</li> 
										<div class="clear"> </div>
										<li>
										<textarea class="plain buffer" name="message" placeholder="Your text here"> Your text here</textarea>
										</li>
										<input class="send" type="submit" value="Send" />
										<!--
									<div class="send">
											<a href="#">SEND</a>
									</div>
									-->
								</ul>
						</form>
				</div>
				<div class="clear"> </div>
					</div>
			</div>
			<div class="footer">
				<div class="wrap">
					<div class="footer-left">
						<h3>About Mobipay</h3>
						<p>Mobipay was designed to help parents to pay fees online without necessarily going to the bank.This helps to reduce problems associated with the bank payment method.</p>
						<p>It also enables direct communication between the school and the parents without involving the students</p>
					<div class="detail">
						<ul>
							<li><a href="#">home/</a></li>
							<li><a href="#">term of services/</a></li>
							<li><a href="#">license/</a></li>
							<li><a href="#">pess</a></li>
							<div class="clear"> </div>	
						</ul>
					</div>
					<div class="soc_icons soc_icons1">
							<ul>
								<li><a class="icon1" href="#"> </a> </li>
								<li><a class="icon2" href="#"> </a></li>
								<li><a class="icon3" href="#"> </a></li>
								<div class="clear"> </div>	
							</ul>
								
					</div>
					</div>
					<div class="footer-right">
						<h3>twitter</h3>
						<div class="comments1">
							<p>I just cant imagine i don't have to go to school every time i want to pay fees.It feels so good being able to pay for my son just sitted at my house.</p>
							<span>~12 hours ago</span>
						</div>
						<div class="comments1">
							<p>.</p>
							<span>~2 days ago</span>
						</div>
					</div>
					<div class="clear"> </div>	
				</div>
			</div>
			<div class="copy">
				       <p>� 2014 Template by <a href="http://w3layouts.com" target="_blank">w3layouts</a></p>
			  </div>
</body>
</body>
</html>
