<?php

$conn= mysqli_connect("localhost","apphivec_testdb","Gi10807108","apphivec_testdb");
$sql= "SELECT * FROM communicate";
$result=mysqli_query($sql,$conn) or die (mysqli_error($db));;
 while($resarray=mysql_fetch_assoc($result)){
   foreach($resarray as $key=>$value){
    
     print"$value<br>";
   }
 }
?>