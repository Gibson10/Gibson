<?php
$firstname=$_POST['firstname'];
?>
<html>
<head>
<title></title>
</head>
<body>

Dear <?php print "$firstname"?> your email has been received we will get back to you soon.Thank you.
</body>
</html>