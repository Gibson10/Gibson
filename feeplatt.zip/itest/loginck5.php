
<!DOCTYPE html>
<html>
<head>
<title>insert.html</title>
<meta charset="UTF_8">
<meta lang="en">
<style type="text/css">
</style>
</head>
<body>
<?php
$name=$_POST['name'];
$password=$_POST['password'];
 $conn=mysql_connect("localhost","root","");
 $sql="SELECT * FROM testdb.neville WHERE name='$name' AND password='$password' ;";
 $result=mysql_query($sql,$conn);
$resarray=mysql_fetch_assoc($result);
if($resarray!=FALSE){
print "<script>
window.location.href ='login.html';
</script>";
 }
 else {print "error wrong username and password combination";
 }
 
 
 ?>
</body>
</html>