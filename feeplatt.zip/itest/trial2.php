<!DOCTYPE html>
<html>
<head>
<title>insert.html</title>
<meta charset="UTF_8">
<meta lang="en">
</head>
<body>
<form action="trial.php"method="POST">
<input type="text"name="name"placeholder="Name"default="">
<input type="password"name="password"placeholder="password"default="">
<input type="email"name="email"placeholder="Email"default="">
<input type="text"name="username"placeholder="username"default="">

<input type="submit"value="Submit">
</form>
</body>
</html>
