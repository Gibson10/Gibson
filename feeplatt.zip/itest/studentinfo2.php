<!DOCTYPE html>
<html>
<head>
<title>insert.html</title>
<meta charset="UTF_8">
<meta lang="en">
<style type="text/css">
</style>
</head>
<body style="background-color:rgb(240,240,240)">
<?php
$name=$_POST['name'];
$admin=$_POST['admin'];
$school=$_POST['school'];
$passcode=$_POST['passcode'];
$conn=mysql_connect("localhost","root","");
$sql="SELECT * FROM testdb.studentinfo WHERE name LIKE '%$name' AND admin LIKE '$admin' AND school LIKE '$school' AND passcode LIKE '$passcode';";
$result=mysql_query($sql,$conn);
 while($resarray=mysql_fetch_assoc($result)){
     print "$resarray[name]  ";
	 print "$resarray[communication]";
 };
 ?>
</body>
</html>