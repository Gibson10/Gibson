<!--A Design by W3layouts
Author: W3layout
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE HTML>
<html>
<head>
<title>The Eracle Website Template | Home :: w3layouts</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<link href='http://fonts.googleapis.com/css?family=Lato:100,300,400,700,900' rel='stylesheet' type='text/css'>
<link href="css/style_2.css" rel="stylesheet" type="text/css" media="all" />
<link rel="stylesheet" type="text/css" href="css/magnific-popup.css">

<script type="text/javascript" src="js/jquery.min.js"></script>
		<!-----768px-menu----->
		<link type="text/css" rel="stylesheet" href="css/jquery.mmenu.all.css" />
		<script type="text/javascript" src="js/jquery.mmenu.js"></script>
			<script type="text/javascript">
				//	The menu on the left
				$(function() {
					$('nav#menu-left').mmenu();
				});
		</script>
		<!-----//768px-menu----->
</head>
<body>
<!-- start header -->
<div class="header_bg">
<div class="wrap">
	<div class="header">
		<div class="logo">
			<a href="index.html">
				<img src="images/platt.jpg" alt=""/>
				<div class="clear">FEEPLATT </div>
			 </a>
		</div>
		<div class="text">
		  <p></p>
		</div>
		<div class="clear"> </div>
	</div>
</div>
</div>

			
  <?php
  $name=$_POST['name'];
  $password=$_POST['password'];
  $email=$_POST['email'];
  $id_no=$_POST['id_no'];
  $bank=$_POST['bank'];
  $account_no=$_POST['account_no'];
  $conn=mysql_connect("localhost","root","");
  $sql="INSERT INTO testdb.neville (name,password,email,id_no,bank,account_no) VALUES ('$name','$password','$email','$id_no','$bank','$account_no');";
  mysql_query($sql,$conn);
  
  print "welcome $name for signing up with us  you can login here ";
  print "<a href=\"login2.php\">login</a>";
  
  ?>
  </body>
  </html>