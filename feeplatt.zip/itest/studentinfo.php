<html>
<head>
<title>insert.html</title>
<meta charset="UTF_8">
<meta lang="en">
</head>
<body>
<form action="studentinfo.php"method="POST">
<input type="date"name="name" placeholder="Enter Name of Student">
<input type="text"name="communicate" placeholder="Enter communication">
<input type="submit"value="submit">
</form>
<?php
$name=$_POST['name'];
$communicate=$_POST['communicate'];
$conn=mysql_connect("localhost","root","");
$sql="INSERT INTO testdb.studentinfo (name,communication) VALUES ('$name','$communicate');";
mysql_query($sql,$conn);  
?>
</body>
</html>