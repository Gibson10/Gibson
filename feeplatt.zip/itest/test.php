<DOCTYPE html>
<html>
<head>
<title></title>
<body>
<?php
$conn=mysql_connect("localhost","root","");
$sql="SELECT * FROM testdb.studentinfo;";
$result=mysql_query($sql,$conn);
 while($resarray=mysql_fetch_assoc($result)){
   foreach($resarray as $key=>$value){
     print ":$value";
   }
 };
?>
</body>
</html>