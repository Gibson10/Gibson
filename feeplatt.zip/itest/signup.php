<?
include "include/session.php";
include "include/newsession.php";
include "config.php";
include "upload.php"; // database connection details stored here
?>
<!DOCTYPE HTML>
<html>
<head>
<link rel="stylesheet" href="css/style2.css"> 
<script type="text/javascript"> 
function validate(form) { 
if (!document.form1.agree.checked) { alert("Please Read the guidlines and check the box below  ."); 
 return false; } 
return true;
}
</script>
<title>MobiPay</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<link href='http://fonts.googleapis.com/css?family=Lato:100,300,400,700,900' rel='stylesheet' type='text/css'>
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/owl.carousel.css" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="css/magnific-popup.css">
<script type="text/javascript" src="js/jquery.min.js"></script>
<script src="js/owl.carousel.js"></script>
	<script>
			$(document).ready(function() {
				$("#owl-demo").owlCarousel({
					items : 4,
					lazyLoad : true,
					autoPlay : true,
					navigation : true,
					navigationText : ["", ""],
					rewindNav : false,
					scrollPerPage : false,
					pagination : false,
					paginationNumbers : false,
				});
			});
		</script>
		<!-- //Owl Carousel Assets -->
		<!-----768px-menu----->
		<link type="text/css" rel="stylesheet" href="css/jquery.mmenu.all.css" />
		<script type="text/javascript" src="js/jquery.mmenu.js"></script>
			<script type="text/javascript">
				//	The menu on the left
				$(function() {
					$('nav#menu-left').mmenu();
				});
		</script>
		<!-----//768px-menu----->
</head>
<body>
<!-- start header -->
<div class="header_bg">
<div class="wrap">
	<div class="header">
		<div class="logo">
			<a href="index.html">
				<img src="images/lg.png" alt=""/>
				<h1>MobiData</h1>
				<div class="clear"> </div>
			 </a>
		</div>
		<div class="text">
		  <p>Kenya's Favourite E-commerce Site</p>
		</div>
		<div class="clear"> </div>
	</div>
</div>
</div>
<!-- start header -->
<div class="header_btm">
	<div class="wrap">
		<!------start-768px-menu---->
			<div id="page">
					<div id="header">
						<a class="navicon" href="#menu-left"> </a>
					</div>
					<nav id="menu-left">
						<ul>
							<li class="active"><a href="index.html"></a></li>
							<li><a href="contact.html"></a></li>
						</ul>
					</nav>
			</div>
		<!------start-768px-menu---->
			<div class="header_sub">
				<div class="h_menu">
					<ul>
						<li class="active"><a href="index.html"></a></li>
						<li><a href="contact.html"></a></li>
					</ul>
				</div>
				<div class="h_search">
		    		<form>
		    			<input type="text" value="" placeholder="search something...">
		    			<input type="submit" value="">
		    		</form>
				</div>
				<div class="clear"> </div>
			</div>
	</div>
</div>
<br>
<body>

<h1> MOBIDATA</h1>
<div>
<form class="sign-up" name=form1 method=post action=signupck.php onsubmit='return validate(this)'>
<input type=hidden name=todo value=post>
<h1 class="sign-up-title">Sign up here <h1>  
User ID             <input class="sign-up-input" type=text name=userid><br>
Sex                 <input class="sign-up-input" type=text name=sex><br>
account no          <input class="sign-up-input" type=text name=account no><br>
Bank                <input class="sign-up-input" type=text name=Bank><br>
email         <input class="sign-up-input" type=text name=email><br>
Password            <input class="sign-up-input" type=password name=password><br>
Re-enter Password   <input class="sign-up-input" type=password name=password2><br>
I agree to terms and conditions<input type=checkbox name=agree value='yes'><br>
<input type=submit value=Signup class="sign-up-button"><br>
</form>
 <p class="about-links">
      <a href=login.php>Login</a> </p>
<?Php
require "bottom.php"; // Tracking who is online
?>
</body>
</html>