
<!--A Design by W3layouts
Author: W3layout
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<?php
require_once("./include/membersite_config.php");
?>
<!DOCTYPE HTML>
<html>
<head>
   <style>
      html, body, #map-canvas {
        height: 100%;
        margin: 0px;
        padding: 0px
      }
    </style>
    <script src="https://maps.googleapis.com/maps/api/js?v=3.exp"></script>
    <script>
var map;
function initialize() {
  var mapOptions = {
    zoom: 8,
    center: new google.maps.LatLng(-1.261491,36.66643)
  };
  map = new google.maps.Map(document.getElementById('map-canvas'),
      mapOptions);
}

google.maps.event.addDomListener(window, 'load', initialize);

    </script>
<title>The Eracle Website Template | Home :: w3layouts</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<link href='http://fonts.googleapis.com/css?family=Lato:100,300,400,700,900' rel='stylesheet' type='text/css'>
<link href="css/style_2.css" rel="stylesheet" type="text/css" media="all" />
<link rel="stylesheet" type="text/css" href="css/magnific-popup.css">
<script type="text/javascript" src="js/jquery.min.js"></script>
		<!-----768px-menu----->
		<link type="text/css" rel="stylesheet" href="css/jquery.mmenu.all.css" />
		<script type="text/javascript" src="js/jquery.mmenu.js"></script>
			<script type="text/javascript">
				//	The menu on the left
				$(function() {
					$('nav#menu-left').mmenu();
				});
		</script>
		<!-----//768px-menu----->
</head>
<body>
<!-- start header -->
<div class="header_bg">
<div class="wrap">
	<div class="header">
		<div class="logo">
			<a href="index.html">
				<img src="images/platt.jpg" alt=""/>
				<h1>FEEPLATT</h1>
				<div class="clear"> </div>
				</a>			               
		</div>
		<div class="text">
		  <p>don't forget to pay your fees using mobipay</p>
		   <p><a href='change-pwd.php'>Change password</a></p>
                <p><a href='logout.php'>Logout</a></p>	 
		</div>
		<div class="clear"> </div>
	</div>
</div>
</div>
<!-- start header -->
<div class="header_btm">
	<div class="wrap">
		<!------start-768px-menu---->
			<div id="page">
					<div id="header">
						<a class="navicon" href="#menu-left"> </a>
					</div>
					<nav id="menu-left">
						<ul>
							<li class="active"><a href="login.html">Home</a></li>
							<li><a href="about.html">About us</a></li>
                                                        <li><a href="pages.html">communications</a></li>
                                                        <li><a href="blog.html">Transactions</a></li>
                                                        <li><a href="contact.html">Contact us</a></li>
                                                        
							
						       
						</ul>
					</nav>
			</div>
		<!------start-768px-menu---->
			<div class="header_sub">
				<div class="h_menu">
					<ul>
						<li class="active"><a href="login.html">Home</a></li>
							<li><a href="about.html">About us</a></li>
                                                        <li><a href="pages.html">communications</a></li>
                                                        <li><a href="blog.html">Transactions</a></li>
                                                        <li><a href="contact.html">Contact us</a></li>
                                                        
							
						        
					</ul>
				</div>
				<div class="h_search">
		    		<form>
		    			<input type="text" value="" placeholder="search something...">
		    			<input type="submit" value="">
		    		</form>
				</div>
				<div class="clear"> </div>
			</div>
	</div>
</div>
<?PHP
require_once("./include/membersite_config.php");
?>
<?php
$name=$_POST['name'];
$school=$_POST['school'];
$amount=$_POST['amount'];
$parentname=$_POST['parentname'];
$number=$_POST['number'];
$bank=$_POST['bank'];
$Card_number=$_POST['Card_number'];
$secretcode=$_POST['secretcode'];
$conn=mysql_connect("localhost","root","");
 $sql="UPDATE testdb.schoolbalances SET amount=amount-$amount where school='$school' AND number='$number';";
 mysql_query($sql,$conn);
$sql="INSERT INTO testdb.paidparents (parentname,amount,school,name,number) VALUES ('$parentname','$amount','$school','$name','$number');";
mysql_query($sql,$conn);
$sql="INSERT INTO testdb.creditcard (bank,Card_number,secretcode) VALUES ('$bank','$Card_number','$secretcode');";
mysql_query($sql,$conn);
  print <<<HERE
<h4>Congratulation <br>
You Have Paid<br> 
amount: $amount; <br>
name of student:$name <br>
school: $school.<br>
<script type="text/javascript">
document.write("Today is " + Date() );
</script>


<a href='login-home.php'>Continue Using Site</a></h4>
HERE;
print "Your new balance is:<br>";
$sql2="SELECT amount FROM testdb.schoolbalances where school='$school' AND number='$number';";
$result=mysql_query($sql2,$conn); 
while($resarray=mysql_fetch_assoc($result)) {
print "$resarray[amount]";
}
?>
</body>
</html>