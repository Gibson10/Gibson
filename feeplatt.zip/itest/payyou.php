<?PHP
require_once("./include/membersite_config.php");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US">
<head>
      <meta http-equiv='Content-Type' content='text/html; charset=utf-8'/>
      <title>Pay Fees</title>
      <link rel="STYLESHEET" type="text/css" href="style/fg_membersite.css" />
      <script type='text/javascript' src='scripts/gen_validatorv31.js'></script>
      <link rel="stylesheet" href="css/style.css">
  
</head>

<body>
  
<form class="sign-up" action="payyouck.php" method='post' accept-charset='UTF-8'>
    
<h1 class="sign-up-title">PREPARE  HIS FUTURE</h1>
   
<input type='hidden' name='submitted' id='submitted' value='1'/> 
<div class='container'><span id='login_username_errorloc' class='error'></span></div>
<div><span class='error'><?php echo $fgmembersite->GetErrorMessage(); ?></span></div>
<input type="text" class="sign-up-output" placeholder="Student Name" name='name' id='username' maxlength="50" autofocus>
<input type="text" class="sign-up-output" placeholder="Parent Name" name='parentname' id='username' maxlength="50" autofocus>
<select class="sign-up-output" name='school' id='username' maxlength="50" placeholder="Choose The School..">
   <option value="Alliance High School">Alliance High School</option>
   <option value="Mangu High School">Mang'u High School</option>
   <option value="Kenya High School">Kenya High School</option>
   <option value="Loreto Limuru School">Loreto Limuru School</option>
</select>
<input type="number" class="sign-up-output" placeholder="Amount" name="amount" id="amount" maxlength="10" > 
<input type="password" class="sign-up-output" placeholder="Enter your password" name='password' id='password' maxlength="50" >
 
<span id='login_password_errorloc' class='error'></span>
   
<input type="submit" value="Confirm Payment" class="sign-in-button" name='Submit' action="paid.php" >
  
</form>

  
<div class="about">
    
<p class="about-links">
 
<a href="index.html">Home</a>
 
<a href='reset-pwd-req.php'  target="_parent">Forgot Password?</a>     
     

</p>
    
<p class="about-author">
      &copy; MobiPay  2013 
      
<a href="http://www.cssflow.com/mit-license" target="_blank">MIT License</a><br>
 

<div class='short_explanation'>* required fields</div>     

    </p>
  </div>

</form>
<!-- client-side Form Validations:
Uses the excellent form validation script from JavaScript-coder.com-->

<script type='text/javascript'>
// <![CDATA[

    var frmvalidator  = new Validator("login");
    frmvalidator.EnableOnPageErrorDisplay();
    frmvalidator.EnableMsgsTogether();

    frmvalidator.addValidation("username","req","Please specify a student");
    frmvalidator.addvalidation("amount","req","Please give an Amount");
    frmvalidator.addValidation("password","req","Please provide the password");

// ]]>
</script>
</div>
<!--
Form Code End (see html-form-guide.com for more info.)
-->

</body>
</html>