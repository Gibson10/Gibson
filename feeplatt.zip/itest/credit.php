<!--A Design by W3layouts
Author: W3layout
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<?php
require_once("./include/membersite_config.php");
?>
<!DOCTYPE HTML>
<html>
<head>
   <style>
      html, body, #map-canvas {
        height: 100%;
        margin: 0px;
        padding: 0px
      }
    </style>
    <script src="https://maps.googleapis.com/maps/api/js?v=3.exp"></script>
    <script>
var map;
function initialize() {
  var mapOptions = {
    zoom: 8,
    center: new google.maps.LatLng(-1.261491,36.66643)
  };
  map = new google.maps.Map(document.getElementById('map-canvas'),
      mapOptions);
}

google.maps.event.addDomListener(window, 'load', initialize);

    </script>
<title>Mobipay</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<link href='http://fonts.googleapis.com/css?family=Lato:100,300,400,700,900' rel='stylesheet' type='text/css'>
<link href="css/style_2.css" rel="stylesheet" type="text/css" media="all" />
<link rel="stylesheet" type="text/css" href="css/magnific-popup.css">
<link rel="stylesheet" type="text/css" href="css/style4.css">

<script type="text/javascript" src="js/jquery.min.js"></script>
		<!-----768px-menu----->
		<link type="text/css" rel="stylesheet" href="css/jquery.mmenu.all.css" />
		<script type="text/javascript" src="js/jquery.mmenu.js"></script>
			<script type="text/javascript">
				//	The menu on the left
				$(function() {
					$('nav#menu-left').mmenu();
				});
		</script>
		<!-----//768px-menu----->
</head>
<body>
<!-- start header -->
<div class="header_bg">
<div class="wrap">
	<div class="header">
		<div class="logo">
			<a href="index.html">
				<img src="images/platt.jpg" alt=""/>
				<h1>FEEPLATT</h1>
				<div class="clear"> </div>
				</a>			               
		</div>
		<div class="text">
		  <p>Kenya's Favourite Online payment Site</p>
<p><a href='reset.php'>Change password</a></p>
<p><a href='logout.php'>Logout</a></p>
		</div>
		<div class="clear"> </div>
	</div>
</div>
</div>
<!-- start header -->
<div class="header_btm">
	<div class="wrap">
		<!------start-768px-menu---->
			<div id="page">
					<div id="header">
						<a class="navicon" href="#menu-left"> </a>
					</div>
					<nav id="menu-left">
						<ul>
							<li class="active"><a href="login.html">Home</a></li>
							<li><a href="about.html">About us</a></li>
                                                        <li><a href="pages.html">communications</a></li>
                                                        <li><a href="blog.html">Transactions</a></li>
                                                        <li><a href="contact.html">Contact us</a></li>
                                                        
							
						       
						</ul>
					</nav>
			</div>
		<!------start-768px-menu---->
			<div class="header_sub">
				<div class="h_menu">
					<ul>
						<li class="active"><a href="login.html">Home</a></li>
							<li><a href="about.html">About us</a></li>
                                                        <li><a href="pages.html">communications</a></li>
                                                        <li><a href="blog.html">Transactions</a></li>
                                                        <li><a href="contact.html">Contact us</a></li>
                                                        
							
						        
					</ul>
				</div>
				<div class="h_search">
		    		<form>
		    			<input type="text" value="" placeholder="search something...">
		    			<input type="submit" value="">
		    		</form>
				</div>
				<div class="clear"> </div>
			</div>
	</div>
</div>
		<div class="header_bottom">
		</div>
		<!-----end-header-------->
		<!---start-getintouch---->
			<div class="get-intouch" id="contact">
				<div class="wrap">
					<h3>Contact Us</h3>
				<div class="get-intouch-grids"><?PHP
require_once("./include/membersite_config.php");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US">
<head>
      <meta http-equiv='Content-Type' content='text/html; charset=utf-8'/>
      <title>Pay Fees</title>
      <link rel="STYLESHEET" type="text/css" href="style/fg_membersite.css" />
      <script type='text/javascript' src='scripts/gen_validatorv31.js'></script>
      <link rel="stylesheet" href="css/style.css">
  
</head>
<body>
  
<form class="sign-up" action="credit2.php" method='post' accept-charset='UTF-8'>
    
<h1 class="sign-up-title">Pay Now</h1>
   
<input type='hidden' name='submitted' id='submitted' value='1'/> 
<div class='container'><span id='login_username_errorloc' class='error'></span></div>
<div><span class='error'><?php echo $fgmembersite->GetErrorMessage(); ?></span></div>
<input type="text" class="sign-up-output" placeholder="Student Name" name='name' id='username' maxlength="50" autofocus>
<input type="text" class="sign-up-output" placeholder="Parents Name" name='parentname' id='username' maxlength="50" autofocus>
<input type="text" class="sign-up-output" placeholder="Admision Number" name='number' id='username' maxlength="50" autofocus>
<select class="sign-up-output" name='school' id='username' maxlength="50" placeholder="Choose The School..">
   <option value="Alliance High School"selected>Alliance High School</option>
   <option value="Mangu High School">Mang'u High School</option>
   <option value="Kenya High School">Kenya High School</option>
   <option value="Loreto Limuru School">Loreto Limuru School</option>
    <option value="Kenya High School">State House Girls</option>
   <option value="Loreto Limuru School">Moi Kabarak School</option>
    <option value="Kenya High School">Limuru Girls</option>
   <option value="Loreto Limuru School">Maranda School</option>
</select>
<input type="number" class="sign-up-output" placeholder="Amount" name='amount' id="amount" maxlength="10" >
<input type="text" class="sign-up-output" placeholder="bank" name='bank' id="amount" maxlength="10" > 
<input type="number" class="sign-up-output" placeholder="card_number" name='Card_number' id="amount" maxlength="10" > 
<input type="password" class="sign-up-output" placeholder="secret number" name='secretcode' id="amount" maxlength="10" > 
<input type="password" class="sign-up-output" placeholder="Enter your password" name='password' id='password' maxlength="50" >
 
<span id='login_password_errorloc' class='error'></span>
   
<input type="submit" value="Confirm Payment" class="sign-in-button" name='Submit' action="paid.php" >

</form>
  

  
<div class="about">
    
<p class="about-links">
 
<a href="index.html">Home</a>
 
<a href='reset-pwd-req.php'  target="_parent">Forgot Password?</a>     
     

</p>
    
<p class="about-author">
      &copy; MobiPay  2013 
      
<a href="http://www.cssflow.com/mit-license" target="_blank">MIT License</a><br>
 

<div class='short_explanation'>* required fields</div>     

    </p>
  </div>

</form>
<!-- client-side Form Validations:
Uses the excellent form validation script from JavaScript-coder.com-->

<script type='text/javascript'>
// <![CDATA[

    var frmvalidator  = new Validator("login");
    frmvalidator.EnableOnPageErrorDisplay();
    frmvalidator.EnableMsgsTogether();

    frmvalidator.addValidation("username","req","Please specify a student");
    frmvalidator.addvalidation("amount","req","Please give an Amount");
    frmvalidator.addValidation("password","req","Please provide the password");

// ]]>
</script>
</div>
<!--
Form Code End (see html-form-guide.com for more info.)
-->

</body>
</html>
					<div class="get-intouch-left-address">
						<h4>One can get in touch to us through email or WhatsApp @0718365967</h4>
						<p>One can also use our facebook account at mobipay.</p>
						<p>We are located at nairobi KCB bank.</p>
						<p>Feel free to visit us or send any complaints</p>
						<p><a href="mailto:mobipay@gmail.com">mobipay@gmail.com</a></p>
						<a href="schoolinfo2.php"><h1><button><div class="button send_button">view schools contacts</div></button></h1></a>
					</div>
					<div class="get-intouch-center-form">
						<h5>Say hello!</h5>
						<form method="post" action="messages.php">
							<input class="frist" type="text" value="Name" name="name" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Name';}"required="required">
							<input type="text" value="Email"name="email"onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Email';}"required="required">
						<input type="text"value="enter message"name="message"onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'message';}" required="required">
				       </textarea>
							<input type="submit" value="Send message" />
							<div class="clear"> </div>
						</form>
					</div>
					<!-- aToolTip js -->
						<script type="text/javascript" src="js/jquery.atooltip.js"></script>
						<script type="text/javascript">
							$(function(){ 
								$('a.normalTip').aToolTip();
								}); 
						</script>
					<div class="clear"> </div>
				</div>
				</div>
				<div class="map">
 <div id="map-canvas" width="100%" height="200" frameborder="0" scrolling="no" marginheight="0" marginwidth="0"></div>

								</div>
			</div>
			<!---//End-getintouch---->
			<!----start footer------>
			<div class="footer">
				<div class="wrap">
					<div class="footer-left">
						<h3>About Mobipay</h3>
						<p>Mobipay was designed to help parents to pay fees online without necessarily going to the bank.This helps to reduce</p>
						<p>It also enables direct communication between the school and the parents without involving the students</p>
					<div class="detail">
						<ul>
							<li><a href="#">home/</a></li>
							<li><a href="#">term of services/</a></li>
							<li><a href="#">license/</a></li>
							<li><a href="#">pess</a></li>
							<div class="clear"> </div>	
						</ul>
					</div>
					<div class="soc_icons soc_icons1">
							<ul>
								<li><a class="icon1" href="#"> </a> </li>
								<li><a class="icon2" href="#"> </a></li>
								<li><a class="icon3" href="#"> </a></li>
								<div class="clear"> </div>	
							</ul>
								
					</div>
					</div>
					<div class="footer-right">
						<h3>twitter</h3>
						<div class="comments1">
							<p>Find us on twitter to know more about us and how we work.We are more than ready to help you</p>
							<span>~12 hours ago</span>
						</div>
						<div class="comments1">
							<p></p>
							<span>~2 days ago</span>
						</div>
					</div>
					<div class="clear"> </div>	
				</div>
			</div>
			<div class="copy">
				     
			  </div>
</body>
</html>