<DOCTYPE html>
<html>
<head>
<title>paid</title>
</head>
<body>
You Have Paid 10000 sh For your son At Alliance High School.Your receipt Will come After 5 Minutes
</body>
</html>