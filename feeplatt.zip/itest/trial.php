<!DOCTYPE HTML>
<html>
<head>
  <title></title>
  </head>
  <body>
  <?php
  $name=$_POST['name'];
  $password=$_POST['password'];
  $email=$_POST['email'];
  $username=$_POST['username'];
  $conn=mysql_connect("localhost","root","");
  $sql="INSERT INTO backup.users (name,password,email,username,) VALUES ('$name','$password','$email','$username');";
  mysql_query($sql,$conn);
  ?>
  </body>
  </html>