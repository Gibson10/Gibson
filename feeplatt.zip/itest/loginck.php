
<!DOCTYPE html>
<html>
<head>
<title>insert.html</title>
<meta charset="UTF_8">
<meta lang="en">
<style type="text/css">
</style>
</head>
<body>
<?php
$name=$_POST['name'];
 $conn=mysql_connect("localhost","root","");
 $sql="SELECT * FROM testdb.neville WHERE name='$name' ;";
 $result=mysql_query($sql,$conn);
$resarray=mysql_fetch_assoc($result);
if($resarray!=FALSE){

  echo '<META HTTP-EQUIV="Refresh" Content="0; URL=login-home.php">';    
    exit;    
 }
 else {print"error";
 }
 
 
 ?>
</body>
</html>