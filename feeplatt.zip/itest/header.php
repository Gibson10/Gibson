<?php
require_once("./include/membersite_config.php");
$logo=<<<HERE
		<div class="logo">
			<a href="access-controlled.php">
				<img src="images/lg.png" alt=""/>
								<div class="clear"> </div>
			 </a>
		</div>
HERE;
$username=$fgmembersite->UserFullName();
$user=<<<HERE
		<div class="text">
		  <img src="images/guest.jpg" alt="guest">

			<div class="pname">
$username
</div>
			<a href="login.php" id=""> $username Login</a>
		</div>
		<div class="clear"> </div>
</div>
	</div>
HERE;
$header=
'<div class="header_bg"><div class="wrap"><div class="header">'
.$logo.$user.
'</div></div>'
;
?>